const searchInput = document.getElementById("trafficSearch");
const clearButton = document.getElementById("clearSearch");
const apiCards = document.querySelectorAll(".api-card");
const noResults = document.getElementById("noResults");
const apiList = document.getElementById("apiList");

function filterCards() {
    const query = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;

    apiCards.forEach((card) => {
        const text = card.textContent.toLowerCase();
        const matches = text.includes(query);

        card.hidden = !matches;

        if (matches) {
            visibleCount++;
        }
    });

    // Hide the blank gaps when searching
    document.querySelectorAll(".api-spacer").forEach((spacer) => {
        spacer.hidden = query.length > 0;
    });

}

searchInput.addEventListener("input", filterCards);

clearButton.addEventListener("click", () => {
    searchInput.value = "";
    filterCards();
    searchInput.focus();
});

// ========================================
// LOGIN PAGE TO DASHBOARD
// ========================================

const loginPage = document.getElementById("loginPage");
const loginForm = document.getElementById("loginForm");
const trafficApp = document.getElementById("trafficApp");

// Show dashboard after login
function showDashboard(event) {
    if (event) {
        event.preventDefault();
    }

    // Hide the login page
  loginPage.querySelector(".login-card").style.display = "none";
    // Show the Traffic Station dashboard
    trafficApp.hidden = false;
    trafficApp.style.display = "block";
}

// Normal login
if (loginForm) {
    loginForm.addEventListener("submit", showDashboard);
}

// Google login - open dashboard directly
const googleLoginBtn = document.getElementById("googleLoginBtn");

if (googleLoginBtn) {
    googleLoginBtn.addEventListener("click", function (event) {
        event.preventDefault();

        loginPage.style.display = "none";
        trafficApp.hidden = false;
        trafficApp.style.display = "block";
    });
}

// Forgot password
const forgotPasswordLink =
    document.getElementById("forgotPasswordLink");

if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener("click", function (event) {
        event.preventDefault();

        alert(
            "For this demo, click Login with Google to open the dashboard."
        );
    });
}
// PLAN ROUTES NAVIGATION
const planRoutesBtn = document.getElementById("planRoutesBtn");
const planRoutesPage = document.getElementById("planRoutesPage");
const dashboardPage = document.getElementById("dashboardPage");

if (planRoutesBtn && planRoutesPage) {
    planRoutesBtn.addEventListener("click", function () {

        // Hide the main dashboard
        if (dashboardPage) {
            dashboardPage.style.display = "none";
        }

        // Show the Plan Routes page
        planRoutesPage.style.display = "block";

        // Highlight Plan Routes
        document.querySelectorAll(".nav-item").forEach(btn => {
            btn.classList.remove("active");
        });

        planRoutesBtn.classList.add("active");
    });
}
// ========================================
// ROUTE CALCULATION
// ========================================

const startLocationInput = document.getElementById("startLocation");
const destinationLocationInput = document.getElementById("destinationLocation");
const calculateRouteBtn = document.getElementById("calculateRouteBtn");
const routeResult = document.getElementById("routeResult");

// Convert a location name into latitude and longitude
async function getCoordinates(location) {
    const url =
        `https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q=${encodeURIComponent(location + ", Hyderabad, Telangana")}`;

    const response = await fetch(url);

    if (!response.ok) {
        throw new Error("Unable to search for this location.");
    }

    const data = await response.json();

    if (data.length === 0) {
        throw new Error(`Location not found: ${location}`);
    }

    return {
        latitude: Number(data[0].lat),
        longitude: Number(data[0].lon),
        name: data[0].display_name
    };
}

// Calculate the road route using OSRM
async function calculateRoute() {
    const start = startLocationInput.value.trim();
    const destination = destinationLocationInput.value.trim();

    // Check whether both locations are entered
    if (!start || !destination) {
        routeResult.innerHTML =
            "<p>Please enter both starting location and destination.</p>";
        return;
    }

    calculateRouteBtn.disabled = true;
    calculateRouteBtn.textContent = "Calculating...";

    routeResult.innerHTML =
        "<p>Finding your route. Please wait...</p>";

    try {
        // Get coordinates for both locations
        const startCoords = await getCoordinates(start);
        const destinationCoords = await getCoordinates(destination);

        // OSRM requires longitude,latitude
        const routeURL =
            `https://router.project-osrm.org/route/v1/driving/` +
            `${startCoords.longitude},${startCoords.latitude};` +
            `${destinationCoords.longitude},${destinationCoords.latitude}` +
            `?overview=false&steps=false`;

        const response = await fetch(routeURL);

        if (!response.ok) {
            throw new Error("Unable to calculate the road route.");
        }

        const data = await response.json();

        if (data.code !== "Ok" || !data.routes.length) {
            throw new Error("No driving route was found.");
        }

        const route = data.routes[0];

        // Convert metres to kilometres
        const distanceKm = (route.distance / 1000).toFixed(2);

        // Convert seconds to hours and minutes
        const totalMinutes = Math.round(route.duration / 60);
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;

        let travelTime = "";

        if (hours > 0) {
            travelTime += `${hours} hr `;
        }

        travelTime += `${minutes} min`;

        // Display the result
        routeResult.innerHTML = `
            <div class="route-result-card">
                <h3>Route Calculated Successfully!</h3>

                <p>
                    <strong>Starting Location:</strong>
                    ${escapeRouteText(start)}
                </p>

                <p>
                    <strong>Destination:</strong>
                    ${escapeRouteText(destination)}
                </p>

                <p>
                    <strong>Road Distance:</strong>
                    ${distanceKm} km
                </p>

                <p>
                    <strong>Estimated Travel Time:</strong>
                    ${travelTime}
                </p>

                <small>
                    Distance and travel time are estimates.
                    Actual conditions may vary.
                </small>
            </div>
        `;

    } catch (error) {
        routeResult.innerHTML = `
            <p class="route-error">
                ${escapeRouteText(error.message)}
                Please check your locations and try again.
            </p>
        `;

    } finally {
        calculateRouteBtn.disabled = false;
        calculateRouteBtn.textContent = "Calculate Route";
    }
}

// Safely display user-entered location names
function escapeRouteText(text) {
    const element = document.createElement("span");
    element.textContent = text;
    return element.innerHTML;
}

// Connect the button to the calculation
if (calculateRouteBtn && routeResult &&
    startLocationInput && destinationLocationInput) {

    calculateRouteBtn.addEventListener("click", calculateRoute);
}