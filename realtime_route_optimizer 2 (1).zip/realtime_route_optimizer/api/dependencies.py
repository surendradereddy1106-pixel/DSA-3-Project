from typing import Dict, Any


# Shared in-memory application state
app_state: Dict[str, Any] = {
    "vehicles": {},
    "orders": {},
    "telemetry": {},
    "routes": {},
}


def get_app_state() -> Dict[str, Any]:
    """
    Return the shared application state.
    """

    return app_state