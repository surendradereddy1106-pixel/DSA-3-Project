from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import List

router = APIRouter(tags=["Routes"])

class RouteRequest(BaseModel):
    origin: str = Field(..., example="Point A")
    destination: str = Field(..., example="Point B")
    avoid_tolls: bool = Field(False)

class RouteResponse(BaseModel):
    route_id: str
    total_distance_km: float
    estimated_time_minutes: float
    path: List[str]

@router.post("/route", response_model=RouteResponse, summary="Calculate optimal route")
def calculate_optimal_route(request: RouteRequest):
    return {
        "route_id": "route_12345",
        "total_distance_km": 18.2,
        "estimated_time_minutes": 25.0,
        "path": [request.origin, "Intermediate Waypoint", request.destination]
    }