from fastapi import APIRouter, status
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter(tags=["Incidents"])

class Incident(BaseModel):
    id: Optional[str] = None
    title: str
    description: str
    location: str
    severity: str

@router.get("/incidents", response_model=List[Incident], summary="Get active road incidents")
def get_active_road_incidents():
    return [
        {
            "id": "inc_001",
            "title": "Vehicle Breakdown",
            "description": "Right lane blocked",
            "location": "Highway 101 KM 42",
            "severity": "Low"
        }
    ]

@router.post("/incidents/report", response_model=Incident, status_code=status.HTTP_201_CREATED, summary="Report a new road incident")
def report_new_road_incident(incident: Incident):
    new_incident = incident.model_dump() if hasattr(incident, "model_dump") else incident.dict()
    new_incident["id"] = "inc_002"
    return new_incident