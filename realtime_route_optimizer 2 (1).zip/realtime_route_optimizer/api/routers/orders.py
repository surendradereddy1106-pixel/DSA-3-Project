from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from api.dependencies import get_app_state
router = APIRouter(
    prefix="/orders",
    tags=["Orders"],
)


class Order(BaseModel):
    order_id: str
    pickup_latitude: float
    pickup_longitude: float
    delivery_latitude: float
    delivery_longitude: float
    priority: str = "normal"
    status: str = "pending"
    customer_name: Optional[str] = None


@router.get("/")
async def get_orders():
    """
    Return all orders.
    """

    state = get_app_state()

    return {
        "success": True,
        "orders": list(
            state["orders"].values()
        ),
    }


@router.post("/")
async def create_order(order: Order):
    """
    Create a new delivery order.
    """

    state = get_app_state()

    if order.order_id in state["orders"]:
        raise HTTPException(
            status_code=409,
            detail="Order already exists",
        )

    order_data = order.model_dump()

    state["orders"][
        order.order_id
    ] = order_data

    return {
        "success": True,
        "message": "Order created successfully",
        "order": order_data,
    }


@router.get("/{order_id}")
async def get_order(order_id: str):
    """
    Return one order.
    """

    state = get_app_state()

    order = state["orders"].get(
        order_id
    )

    if order is None:
        raise HTTPException(
            status_code=404,
            detail="Order not found",
        )

    return {
        "success": True,
        "order": order,
    }


@router.put("/{order_id}/status")
async def update_order_status(
    order_id: str,
    status: str,
):
    """
    Update an order status.
    """

    state = get_app_state()

    order = state["orders"].get(
        order_id
    )

    if order is None:
        raise HTTPException(
            status_code=404,
            detail="Order not found",
        )

    order["status"] = status

    return {
        "success": True,
        "message": "Order status updated",
        "order": order,
    }


@router.delete("/{order_id}")
async def delete_order(order_id: str):
    """
    Delete an order.
    """

    state = get_app_state()

    if order_id not in state["orders"]:
        raise HTTPException(
            status_code=404,
            detail="Order not found",
        )

    del state["orders"][order_id]

    return {
        "success": True,
        "message": "Order deleted successfully",
    }