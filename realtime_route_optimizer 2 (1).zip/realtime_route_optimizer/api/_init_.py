"""
API layer for the Realtime Route Optimizer.
"""