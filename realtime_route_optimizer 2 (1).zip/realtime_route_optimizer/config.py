from dataclasses import dataclass
import os


@dataclass
class Settings:
    app_name: str = "Realtime Route Optimizer"
    app_version: str = "1.0.0"
    host: str = os.getenv("HOST", "127.0.0.1")
    port: int = int(os.getenv("PORT", "8000"))
    debug: bool = os.getenv(
        "DEBUG",
        "true"
    ).lower() == "true"


settings = Settings()