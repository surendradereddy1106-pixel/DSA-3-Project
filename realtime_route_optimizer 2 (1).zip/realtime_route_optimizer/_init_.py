"""
API routers for the Realtime Route Optimizer.
"""