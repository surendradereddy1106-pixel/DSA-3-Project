from fastapi import FastAPI, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path

app = FastAPI(
    title="Traffic Station API",
    description="Hyderabad Traffic Police Station Search",
    version="1.0.0"
)
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
app.mount(
    "/static",
    StaticFiles(directory=STATIC_DIR),
    name="static"
)

HYDERABAD_TRAFFIC_STATIONS = [
    "Abids Traffic Police Station",
    "Afzal Gunj Traffic Police Station",
    "Amberpet Traffic Police Station",
    "Asif Nagar Traffic Police Station",
    "Attapur Traffic Police Station",
    "Bahadurpura Traffic Police Station",
    "Banjara Hills Traffic Police Station",
    "Begumpet Traffic Police Station",
    "Bowenpally Traffic Police Station",
    "Chaderghat Traffic Police Station",
    "Chandrayangutta Traffic Police Station",
    "Charminar Traffic Police Station",
    "Chilkalguda Traffic Police Station",
    "Chintal Traffic Police Station",
    "Chowk Traffic Police Station",
    "Dabeerpura Traffic Police Station",
    "Domalguda Traffic Police Station",
    "Falaknuma Traffic Police Station",
    "Film Nagar Traffic Police Station",
    "Gandhi Nagar Traffic Police Station",
    "Gachibowli Traffic Police Station",
    "Golconda Traffic Police Station",
    "Habeeb Nagar Traffic Police Station",
    "Hafeezpet Traffic Police Station",
    "Himayatnagar Traffic Police Station",
    "Humayun Nagar Traffic Police Station",
    "Hyderguda Traffic Police Station",
    "Jubilee Hills Traffic Police Station",
    "Kachiguda Traffic Police Station",
    "Karkhana Traffic Police Station",
    "Keesara Traffic Police Station",
    "Khairatabad Traffic Police Station",
    "Kokapet Traffic Police Station",
    "Kondapur Traffic Police Station",
    "Kukatpally Traffic Police Station",
    "Langer Houz Traffic Police Station",
    "LB Nagar Traffic Police Station",
    "Madhapur Traffic Police Station",
    "Madhura Nagar Traffic Police Station",
    "Malakpet Traffic Police Station",
    "Manikonda Traffic Police Station",
    "Maredpally Traffic Police Station",
    "Masab Tank Traffic Police Station",
    "Medchal Traffic Police Station",
    "Mehdipatnam Traffic Police Station",
    "Miyapur Traffic Police Station",
    "Moghalpura Traffic Police Station",
    "Musheerabad Traffic Police Station",
    "Nallakunta Traffic Police Station",
    "Nanakramguda Traffic Police Station",
    "Narayanguda Traffic Police Station",
    "Narsingi Traffic Police Station",
    "Nacharam Traffic Police Station",
    "New Bowenpally Traffic Police Station",
    "Old Airport Road Traffic Police Station",
    "Osmania University Traffic Police Station",
    "Panjagutta Traffic Police Station",
    "Paradise Traffic Police Station",
    "Patancheru Traffic Police Station",
    "Punjagutta Traffic Police Station",
    "Raidurgam Traffic Police Station",
    "Rajendranagar Traffic Police Station",
    "Ramgopalpet Traffic Police Station",
    "Ranigunj Traffic Police Station",
    "Rasoolpura Traffic Police Station",
    "Red Hills Traffic Police Station",
    "Saidabad Traffic Police Station",
    "Sanathnagar Traffic Police Station",
    "Saroornagar Traffic Police Station",
    "Secunderabad Traffic Police Station",
    "Shamshabad Traffic Police Station",
    "Shivam Road Traffic Police Station",
    "Somajiguda Traffic Police Station",
    "SR Nagar Traffic Police Station",
    "Tarnaka Traffic Police Station",
    "Tolichowki Traffic Police Station",
    "Trimulgherry Traffic Police Station",
    "Uppal Traffic Police Station",
    "Vanastalipuram Traffic Police Station",
    "Yousufguda Traffic Police Station"
]

@app.get("/")
def home():
    return FileResponse(BASE_DIR / "index.html")


@app.get("/api/traffic-stations")
def get_traffic_stations(
    q: str = Query(default="", description="Search traffic stations")
):
    query = q.strip().casefold()

    results = [
        station
        for station in HYDERABAD_TRAFFIC_STATIONS
        if query in station.casefold()
    ]

    return {
        "count": len(results),
        "stations": results
    }


app.mount(
    "/",
    StaticFiles(directory=STATIC_DIR, html=True),
    name="static"
)