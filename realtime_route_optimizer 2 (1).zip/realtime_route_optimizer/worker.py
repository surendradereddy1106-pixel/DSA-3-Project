import asyncio
from datetime import datetime, timezone

from realtime_route_optimizer.api.dependencies import get_app_state


async def process_routes():
    """
    Background task for monitoring route optimization.
    """

    while True:
        state = get_app_state()

        vehicle_count = len(state["vehicles"])
        order_count = len(state["orders"])
        route_count = len(state["routes"])

        timestamp = datetime.now(timezone.utc).isoformat()

        print(
            f"[{timestamp}] "
            f"Vehicles: {vehicle_count} | "
            f"Orders: {order_count} | "
            f"Routes: {route_count}"
        )

        await asyncio.sleep(10)


async def main():
    """
    Start the background worker.
    """

    print("Realtime Route Optimizer worker started.")

    await process_routes()


if __name__ == "__main__":
    asyncio.run(main())