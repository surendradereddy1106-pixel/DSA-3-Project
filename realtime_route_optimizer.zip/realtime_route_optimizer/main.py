  from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from typing import List, Dict
import requests
import re
app = FastAPI(
    title="Road Traffic Route Optimiser",
    version="1.0.0",
    description="API for Traffic Data, Route Optimization, and Incidents"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# ----------------------------------------------------
# Traffic Checkposts Data
# ----------------------------------------------------
CHECKPOSTS = [
    {
        "name": "Yousufguda Checkpost",
        "city": "Hyderabad",
        "state": "Telangana",
...